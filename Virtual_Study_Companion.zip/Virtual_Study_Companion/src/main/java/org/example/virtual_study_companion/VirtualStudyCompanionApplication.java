package org.example.virtual_study_companion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtualStudyCompanionApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualStudyCompanionApplication.class, args);
	}

}
