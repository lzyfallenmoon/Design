package org.example.virtual_study_companion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualStudyCompanionApplicationTests {

	@Test
	void contextLoads() {
	}

}
